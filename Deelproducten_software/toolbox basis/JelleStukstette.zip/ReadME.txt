Hierin alle opdrachten die ik heb gemaakt.
Mijn eigen app is de televisieApp met een list een ��n class.
